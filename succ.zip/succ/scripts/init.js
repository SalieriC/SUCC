// Init script
/* globals Hooks, console, CONFIG, ChatMessage, game */

/** Stuff to remember:
 * Turn on hooks: CONFIG.debug.hooks = true;
 * Turn off hooks: CONFIG.debug.hooks = false; or just reload the browser
 */

import { SUCC_DEFAULT_MAPPING, SUCC_DEFAULT_ADDITIONAL_CONDITIONS } from "./default_mappings.js";
import { register_settings } from "./settings.js"
import { output_to_chat } from "./conditions_to_chat.js"
import { effect_updater } from "./effect_updater.js"

//-----------------------------------------------------
// Stuff to do on logging in:
Hooks.on(`ready`, () => {
    console.log('SWADE Ultimate Condition Changer | Ready');
    register_settings();
    if (game.settings.get('succ', 'default_icons') === false) {
        change_conditions();
    }
    add_conditions();

    // Registering templates:
    const templatePaths = ["modules/succ/templates/condition-to-chat.hbs"]
    loadTemplates(templatePaths)

    if (game.modules.get("combat-utility-belt")?.active) {
        new Dialog({
            title: "Incompatibility Warning",
            content: `
            <p>Warning, SUCC is incompatible with Combat Utility Belt.</p>
            <p>Disable Combat Utility Belt in the module settings to avoid bad things from happening.</p>
            <p>You'll see this message on each login so make sure you obey my command or disable SUCC and leave an angry issue on the gitHub. :D</p>
            `,
            buttons: {
                done: {
                    label: "Got it!",
                }
            }
        }).render(true)
    }
});

//-----------------------------------------------------
// To avoid spamming the chat, implement a collecting debouncer outside of the hooks like here: https://discord.com/channels/170995199584108546/722559135371231352/941704126272770118
// Listening to hooks for creating the chat messages:
Hooks.on(`createActiveEffect`, async (condition, _, userID) => {
    if ((condition.data.flags?.core?.statusId in SUCC_DEFAULT_MAPPING ||
        condition.data.flags?.core?.statusId in SUCC_DEFAULT_ADDITIONAL_CONDITIONS) &&
        game.settings.get('succ', 'output_to_chat') === true &&
        game.user.isGM === true) {
        const removed = false
        output_to_chat(condition, removed, userID)
    }
    if (condition.data.flags?.core?.statusId === "smite" || condition.data.flags?.core?.statusId === "protection") {
        effect_updater(condition, userID)
    }
    if (condition.data.flags?.core?.statusId === "incapacitated" && game.settings.get('succ', 'mark_inc_defeated') === true) {
        let actor = condition.parent
        if (actor.data.type === "npc") {
            game.combat?.combatants.forEach(combatant => {
                if (combatant.actor.id === actor.id) {
                    game.combat.updateEmbeddedDocuments('Combatant',
                        [{ _id: combatant.id, defeated: true }]);
                }
            });
        }
    }
});
Hooks.on(`deleteActiveEffect`, async (condition, _, userID) => {
    // __ is the ID of the user who executed the hook, possibly irrelevant in this context.
    if ((condition.data.flags?.core?.statusId in SUCC_DEFAULT_MAPPING ||
        condition.data.flags?.core?.statusId in SUCC_DEFAULT_ADDITIONAL_CONDITIONS) &&
        game.settings.get('succ', 'output_to_chat') === true &&
        game.user.isGM === true) {
        const removed = true
        output_to_chat(condition, removed, userID)
    }
    if (condition.data.flags?.core?.statusId === "incapacitated" && game.settings.get('succ', 'mark_inc_defeated') === true) {
        let actor = condition.parent
        if (actor.data.type === "npc") {
            game.combat?.combatants.forEach(combatant => {
                if (combatant.actor.id === actor.id) {
                    game.combat.updateEmbeddedDocuments('Combatant',
                        [{ _id: combatant.id, defeated: false }]);
                }
            });
        }
    }
});
Hooks.on(`updateActiveEffect`, (condition, toggle, _, userID) => {
    // __ is the ID of the user who executed the hook, possibly irrelevant in this context.
    if ((condition.data.flags?.core?.statusId in SUCC_DEFAULT_MAPPING ||
        condition.data.flags?.core?.statusId in SUCC_DEFAULT_ADDITIONAL_CONDITIONS) &&
        game.settings.get('succ', 'output_to_chat') === true &&
        game.user.isGM === true) {
        // Checking for the updated flag to prevent a repetitive message:
        if (condition.data.flags?.succ?.updatedAE === true) {
            return
        }

        let removed
        if (toggle.disabled === true) {
            removed = true
        } else if (toggle.disabled === false) {
            removed = false
        }
        output_to_chat(condition, removed, userID);
    }
})

// Add buttons to the chat message:
Hooks.on("renderChatMessage", (message, html) => {
    if (html[0].querySelector("div.undo-remove.succ-undo")) {
        html[0].querySelector("div.undo-remove.succ-undo > a[name='undo-remove']").addEventListener("click", () => {
            let actorOrTokenID = message.data.flags.succ.actorOrTokenID
            let condition = message.data.flags.succ.conditionName.toLowerCase().replace(" - ", "-").replace(" ", "-")
            succ.apply_status(actorOrTokenID, condition, true)
        });
    } else if (html[0].querySelector("div.remove-row.succ-remove")) {
        html[0].querySelector("div.remove-row.succ-remove > a[name='remove-row']").addEventListener("click", () => {
            let actorOrTokenID = message.data.flags.succ.actorOrTokenID
            let condition = message.data.flags.succ.conditionName.toLowerCase().replace(" - ", "-").replace(" ", "-")
            succ.apply_status(actorOrTokenID, condition, false)
        });
    }
});
//-----------------------------------------------------

//-----------------------------------------------------
// Changing and adding condition icons
function change_conditions() {
    for (let status of CONFIG.statusEffects) {
        if (status.id in SUCC_DEFAULT_MAPPING) {
            status.icon = SUCC_DEFAULT_MAPPING[status.id]
        }
    }
    let json_icons = game.settings.get('succ', 'icon_overwrites')
    if (json_icons) {
        json_icons = JSON.parse(json_icons)
        for (let status of CONFIG.statusEffects) {
            if (status.id in json_icons) {
                status.icon = json_icons[status.id]
                //console.log(json_icons)
            }
        }
    }
}

async function add_conditions() {
    // Add custom conditions:
    //CONFIG.statusEffects.push({ id: "irradiated", label: "Irradiated", icon: "modules/succ/assets/icons/0-irradiated.svg" });
}
//-----------------------------------------------------